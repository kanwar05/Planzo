import RefreshToken from "../models/RefreshToken.js";
import Availability from "../models/Availability.js";
import Booking from "../models/Booking.js";
import Favorite from "../models/Favorite.js";
import Notification from "../models/Notification.js";
import Review from "../models/Review.js";
import User from "../models/User.js";
import Vendor from "../models/Vendor.js";
import ApiError from "../utils/ApiError.js";
import asyncHandler from "../utils/asyncHandler.js";
import {
  clearAuthCookies,
  createOpaqueToken,
  generateAccessToken,
  getRefreshTokenExpiryDate,
  hashToken,
  REFRESH_COOKIE_NAME,
  setAuthCookies,
} from "../utils/generateToken.js";
import { recalculateVendorRating } from "../utils/reviewRating.js";
import {
  requireFields,
  validateEmail,
} from "../utils/validation.js";
import {
  sendPasswordResetConfirmation,
  sendPasswordResetNotification,
} from "../services/transactionalNotificationService.js";
import { recordAudit } from "../services/auditService.js";

function serializeUser(user) {
  return {
    id: user._id,
    name: user.name,
    email: user.email,
    phone: user.phone,
    role: user.role,
    notificationPreferences: user.notificationPreferences,
    createdAt: user.createdAt,
  };
}

function validatePasswordStrength(password) {
  const value = String(password);
  const problems = [];

  if (value.length < 8) problems.push("at least 8 characters");
  if (!/[a-z]/.test(value)) problems.push("one lowercase letter");
  if (!/[A-Z]/.test(value)) problems.push("one uppercase letter");
  if (!/\d/.test(value)) problems.push("one number");
  if (!/[^A-Za-z0-9]/.test(value)) problems.push("one special character");

  if (problems.length) {
    throw new ApiError(
      400,
      `Password must include ${problems.join(", ")}.`,
    );
  }
}

function getDevice(req) {
  const agent = req.get("user-agent") || "";
  const browser =
    /Edg\//.test(agent) ? "Edge" :
    /Chrome\//.test(agent) ? "Chrome" :
    /Firefox\//.test(agent) ? "Firefox" :
    /Safari\//.test(agent) ? "Safari" : "Unknown browser";
  const type = /Mobile|Android|iPhone|iPad/i.test(agent)
    ? "Mobile device"
    : /Windows/i.test(agent) ? "Windows computer"
    : /Macintosh|Mac OS/i.test(agent) ? "Mac computer"
    : /Linux/i.test(agent) ? "Linux computer" : "Unknown device";
  return { type, browser, ip: req.ip || "Unknown" };
}

async function createRefreshToken(userId, req) {
  const refreshToken = createOpaqueToken();
  await RefreshToken.create({
    userId,
    tokenHash: hashToken(refreshToken),
    expiresAt: getRefreshTokenExpiryDate(),
    device: getDevice(req),
    lastUsedAt: new Date(),
  });

  return refreshToken;
}

async function startSession(req, res, user, statusCode, message) {
  const accessToken = generateAccessToken(user._id);
  const refreshToken = await createRefreshToken(user._id, req);

  setAuthCookies(res, { accessToken, refreshToken });

  res.status(statusCode).json({
    success: true,
    message,
    user: serializeUser(user),
  });
}

function getRefreshTokenFromRequest(req) {
  return req.cookies?.[REFRESH_COOKIE_NAME] || "";
}

async function revokeRefreshToken(token) {
  if (!token) return;

  await RefreshToken.findOneAndUpdate(
    {
      tokenHash: hashToken(token),
      revokedAt: null,
    },
    { revokedAt: new Date() },
  );
}

async function revokeAllUserRefreshTokens(userId) {
  await RefreshToken.updateMany(
    { userId, revokedAt: null },
    { revokedAt: new Date() },
  );
}

export const register = asyncHandler(async (req, res) => {
  requireFields(req.body, ["name", "email", "phone", "password"]);

  const name = String(req.body.name).trim();
  const email = String(req.body.email).trim().toLowerCase();
  const phone = String(req.body.phone).trim();
  const password = String(req.body.password);
  const role = req.body.role || "customer";

  validateEmail(email);
  validatePasswordStrength(password);

  if (!["customer", "vendor"].includes(role)) {
    throw new ApiError(
      400,
      "Public registration supports customer or vendor accounts only.",
    );
  }

  const existingUser = await User.findOne({ email });
  if (existingUser) {
    throw new ApiError(409, "An account with this email already exists.");
  }

  const user = await User.create({ name, email, phone, password, role });
  await startSession(req, res, user, 201, "Account created successfully.");
});

export const login = asyncHandler(async (req, res) => {
  requireFields(req.body, ["email", "password"]);

  const email = String(req.body.email).trim().toLowerCase();
  validateEmail(email);

  const user = await User.findOne({ email }).select("+password");
  const passwordMatches =
    user && (await user.comparePassword(String(req.body.password)));

  if (!user || !passwordMatches) {
    throw new ApiError(401, "Invalid email or password.");
  }
  if (user.accountStatus === "deactivated") {
    throw new ApiError(403, "This account is deactivated. Contact support to reactivate it.");
  }
  if (user.suspendedAt) {
    throw new ApiError(403, "This account is suspended.");
  }

  await recordAudit(req, {
    action: "login",
    actor: user._id,
    admin: null,
    targetType: "User",
    targetId: user._id,
    targetLabel: user.email,
    newValue: { status: "success", role: user.role },
    reason: "Successful login",
  });
  await startSession(req, res, user, 200, "Logged in successfully.");
});

export const refresh = asyncHandler(async (req, res) => {
  const currentRefreshToken = getRefreshTokenFromRequest(req);
  if (!currentRefreshToken) {
    throw new ApiError(401, "Refresh token is missing.");
  }

  const tokenRecord = await RefreshToken.findOne({
    tokenHash: hashToken(currentRefreshToken),
    revokedAt: null,
    expiresAt: { $gt: new Date() },
  });

  if (!tokenRecord) {
    clearAuthCookies(res);
    throw new ApiError(401, "Invalid or expired refresh token.");
  }

  const user = await User.findById(tokenRecord.userId);
  if (!user) {
    tokenRecord.revokedAt = new Date();
    await tokenRecord.save();
    clearAuthCookies(res);
    throw new ApiError(401, "The user for this token no longer exists.");
  }

  tokenRecord.revokedAt = new Date();
  tokenRecord.lastUsedAt = new Date();
  await tokenRecord.save();

  const accessToken = generateAccessToken(user._id);
  const refreshToken = await createRefreshToken(user._id, req);
  setAuthCookies(res, { accessToken, refreshToken });

  res.status(200).json({
    success: true,
    message: "Session refreshed successfully.",
    user: serializeUser(user),
  });
});

export const logout = asyncHandler(async (req, res) => {
  await revokeRefreshToken(getRefreshTokenFromRequest(req));
  clearAuthCookies(res);

  res.status(200).json({
    success: true,
    message: "Logged out successfully.",
  });
});

export const forgotPassword = asyncHandler(async (req, res) => {
  requireFields(req.body, ["email"]);

  const email = String(req.body.email).trim().toLowerCase();
  validateEmail(email);

  const user = await User.findOne({ email }).select(
    "+passwordResetTokenHash +passwordResetExpiresAt name email phone notificationPreferences",
  );

  const response = {
    success: true,
    message:
      "If an account exists for that email, password reset instructions have been sent.",
  };

  if (!user) {
    return res.status(200).json(response);
  }

  const resetToken = createOpaqueToken();
  user.passwordResetTokenHash = hashToken(resetToken);
  user.passwordResetExpiresAt = new Date(Date.now() + 15 * 60 * 1000);
  await user.save({ validateBeforeSave: false });

  if (process.env.NODE_ENV !== "production") {
    response.resetToken = resetToken;
  }

  await sendPasswordResetNotification({ user, resetToken });

  return res.status(200).json(response);
});

export const resetPassword = asyncHandler(async (req, res) => {
  requireFields(req.body, ["token", "password"]);

  const password = String(req.body.password);
  validatePasswordStrength(password);

  const token = String(req.body.token).trim();
  if (!/^[a-f0-9]{96}$/i.test(token)) {
    throw new ApiError(400, "Password reset token is invalid or expired.");
  }

  // Consume the token atomically before changing the password. Two concurrent
  // requests can never successfully use the same reset link.
  const user = await User.findOneAndUpdate({
    passwordResetTokenHash: hashToken(token),
    passwordResetExpiresAt: { $gt: new Date() },
  }, {
    $unset: {
      passwordResetTokenHash: 1,
      passwordResetExpiresAt: 1,
    },
    $set: { passwordResetConsumedAt: new Date() },
  }, {
    new: true,
  }).select("+password +passwordResetConsumedAt");

  if (!user) {
    throw new ApiError(400, "Password reset token is invalid or expired.");
  }

  user.password = password;
  user.passwordChangedAt = new Date();
  await user.save();

  await RefreshToken.updateMany(
    { userId: user._id, revokedAt: null },
    { revokedAt: new Date() },
  );
  clearAuthCookies(res);

  await sendPasswordResetConfirmation({ user });

  res.status(200).json({
    success: true,
    message: "Password reset successfully. Please log in again.",
  });
});

export const updateProfile = asyncHandler(async (req, res) => {
  requireFields(req.body, ["name", "email", "phone"]);

  const name = String(req.body.name).trim();
  const email = String(req.body.email).trim().toLowerCase();
  const phone = String(req.body.phone).trim();

  validateEmail(email);

  if (name.length < 2 || name.length > 80) {
    throw new ApiError(400, "Name must be between 2 and 80 characters.");
  }
  if (phone.length < 7 || phone.length > 20) {
    throw new ApiError(400, "Phone number must be between 7 and 20 characters.");
  }

  const existingUser = await User.findOne({
    email,
    _id: { $ne: req.user._id },
  });
  if (existingUser) {
    throw new ApiError(409, "An account with this email already exists.");
  }

  req.user.name = name;
  req.user.email = email;
  req.user.phone = phone;
  await req.user.save();

  res.status(200).json({
    success: true,
    message: "Profile updated successfully.",
    user: serializeUser(req.user),
  });
});

export const changePassword = asyncHandler(async (req, res) => {
  requireFields(req.body, ["currentPassword", "newPassword"]);

  const user = await User.findById(req.user._id).select("+password");
  const passwordMatches = await user.comparePassword(
    String(req.body.currentPassword),
  );

  if (!passwordMatches) {
    throw new ApiError(401, "Current password is incorrect.");
  }

  const newPassword = String(req.body.newPassword);
  validatePasswordStrength(newPassword);

  user.password = newPassword;
  user.passwordChangedAt = new Date();
  await user.save();

  await revokeAllUserRefreshTokens(user._id);
  clearAuthCookies(res);

  await sendPasswordResetConfirmation({ user });

  res.status(200).json({
    success: true,
    message: "Password changed successfully. Please log in again.",
  });
});

export const updateNotificationPreferences = asyncHandler(async (req, res) => {
  const allowedFields = ["bookingUpdates", "reviewReminders", "promotions"];
  const updates = {};

  for (const field of allowedFields) {
    if (req.body[field] !== undefined) {
      updates[`notificationPreferences.${field}`] = Boolean(req.body[field]);
    }
  }

  if (!Object.keys(updates).length) {
    throw new ApiError(400, "Provide at least one notification preference.");
  }

  const user = await User.findByIdAndUpdate(req.user._id, updates, {
    new: true,
    runValidators: true,
  });

  res.status(200).json({
    success: true,
    message: "Notification preferences updated.",
    user: serializeUser(user),
  });
});

export const deleteAccount = asyncHandler(async (req, res) => {
  requireFields(req.body, ["password"]);

  const user = await User.findById(req.user._id).select("+password");
  const passwordMatches = await user.comparePassword(String(req.body.password));

  if (!passwordMatches) {
    throw new ApiError(401, "Password is incorrect.");
  }

  const vendor = await Vendor.findOne({ userId: user._id });
  const activeBookingFilter = vendor
    ? {
        $or: [
          { customerId: user._id, status: { $in: ["pending", "accepted"] } },
          { vendorId: vendor._id, status: { $in: ["pending", "accepted"] } },
        ],
      }
    : { customerId: user._id, status: { $in: ["pending", "accepted"] } };

  const activeBookings = await Booking.exists(activeBookingFilter);
  if (activeBookings) {
    throw new ApiError(
      409,
      "Cancel or complete active bookings before deleting your account.",
    );
  }

  const reviews = await Review.find({ customerId: user._id }).select("vendorId");
  const affectedVendorIds = [
    ...new Set(reviews.map((review) => String(review.vendorId))),
  ];

  // Cleanup operations
  const cleanupPromises = [
    // Delete customer's favorites
    Favorite.deleteMany({ customerId: user._id }),
    // Delete customer's reviews
    Review.deleteMany({ customerId: user._id }),
    // Delete customer's bookings (non-active)
    Booking.deleteMany({ customerId: user._id, status: { $nin: ["pending", "accepted"] } }),
    // Delete notifications for this user
    Notification.deleteMany({ userId: user._id }),
    // Revoke all refresh tokens
    revokeAllUserRefreshTokens(user._id),
  ];

  // If user is a vendor, add vendor-specific cleanup
  if (vendor) {
    cleanupPromises.push(
      // Delete vendor profile
      vendor.deleteOne(),
      // Delete bookings to this vendor (from other customers)
      Booking.deleteMany({ vendorId: vendor._id, status: { $nin: ["pending", "accepted"] } }),
      // Delete favorites pointing to this vendor
      Favorite.deleteMany({ vendorId: vendor._id }),
      // Delete reviews of this vendor
      Review.deleteMany({ vendorId: vendor._id }),
      // Delete vendor availability
      Availability.deleteOne({ vendorId: vendor._id }),
    );
  }

  await Promise.all(cleanupPromises);

  // Recalculate ratings for vendors affected by customer's deleted reviews
  await Promise.all(
    affectedVendorIds.map((vendorId) => recalculateVendorRating(vendorId)),
  );

  await user.deleteOne();
  clearAuthCookies(res);

  res.status(200).json({
    success: true,
    message: "Account deleted successfully.",
  });
});

export const getMe = asyncHandler(async (req, res) => {
  res.status(200).json({
    success: true,
    user: serializeUser(req.user),
  });
});
